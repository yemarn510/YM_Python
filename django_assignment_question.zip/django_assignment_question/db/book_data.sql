insert into book(id, title, author, publisher, rentalStatus, summary, releaseDate, category)
values
(1, 'Python Programming for the Absolute Beginner', 'Michael Dawson', 'Cengage Learning Ptr', 0, 'The author teaches readers the basics of Python programming through simple game creation', '2010-01-12', 'Programming'),
(2, 'Code Complete second edition', 'Steve McConnell', 'Microsoft Press', 0, 'Widely considered one of the best practical guides to programming', '2004-06-19', 'Programming'),
(3, 'Harry Potter and the Philosophers Stone', 'J. K. Rowling', 'Bloomsbury Childrens Books', 1, 'One of the great famous novel for children, and read all over the world.', '1999-09-01', 'Novel');
